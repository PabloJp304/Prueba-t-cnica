const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Conexión a la base de datos
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // Cambia esto si tu usuario es diferente
    password: '', // Cambia esto si tu contraseña es diferente
    database: 'user_registration' // Cambia esto al nombre de tu base de datos
});

db.connect(err => {
    if (err) {
        console.error('Error conectando a la base de datos:', err);
        return;
    }
    console.log('Conectado a la base de datos MySQL');
});

// Ruta para la raíz
app.get('/', (req, res) => {
    res.send('¡Bienvenido a la API de registro de usuarios!');
});

// Ruta para almacenar datos del formulario
app.post('/api/users', (req, res) => {
    const userData = req.body;

    const query = `
        INSERT INTO Users (document_number, first_name, second_name, first_last_name, second_last_name, phone, email, address, age, gender)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [
        userData.documentNumber,
        userData.firstName,
        userData.secondName,
        userData.firstLastName,
        userData.secondLastName,
        userData.phone,
        userData.email,
        userData.address,
        userData.age,
        userData.gender
    ], (error, results) => {
        if (error) {
            console.error('Error al insertar datos:', error);
            return res.status(500).send('Error al insertar datos');
        }
        res.status(201).send({ id: results.insertId });
    });
});

// Ruta para consultar el nombre completo de todas las personas
app.get('/api/users', (req, res) => {
    const query = `
        SELECT CONCAT(first_name, ' ', second_name, ' ', first_last_name, ' ', second_last_name) AS full_name
        FROM Users
    `;
    db.query(query, (error, results) => {
        if (error) {
            console.error('Error al consultar nombres:', error);
            return res.status(500).send('Error al consultar nombres');
        }
        res.status(200).json(results);
    });
});

// Ruta para contar cuántas mujeres hay
app.get('/api/users/females/count', (req, res) => {
    const query = `SELECT COUNT(*) AS female_count FROM Users WHERE gender = 'Femenino'`;
    db.query(query, (error, results) => {
        if (error) {
            console.error('Error al contar mujeres:', error);
            return res.status(500).send('Error al contar mujeres');
        }
        res.status(200).json(results[0]);
    });
});

// Ruta para contar cuántos hombres hay
app.get('/api/users/males/count', (req, res) => {
    const query = `SELECT COUNT(*) AS male_count FROM Users WHERE gender = 'Masculino'`;
    db.query(query, (error, results) => {
        if (error) {
            console.error('Error al contar hombres:', error);
            return res.status(500).send('Error al contar hombres');
        }
        res.status(200).json(results[0]);
    });
});

// Ruta para obtener el nombre completo de la persona con mayor edad
app.get('/api/users/oldest', (req, res) => {
    const query = `
        SELECT CONCAT(first_name, ' ', second_name, ' ', first_last_name, ' ', second_last_name) AS full_name
        FROM Users
        ORDER BY age DESC
        LIMIT 1
    `;
    db.query(query, (error, results) => {
        if (error) {
            console.error('Error al consultar la persona mayor:', error);
            return res.status(500).send('Error al consultar la persona mayor');
        }
        res.status(200).json(results[0]);
    });
});

// Ruta para calcular el promedio de la edad
app.get('/api/users/average-age', (req, res) => {
    const query = `SELECT AVG(age) AS average_age FROM Users`;
    db.query(query, (error, results) => {
        if (error) {
            console.error('Error al calcular el promedio de edad:', error);
            return res.status(500).send('Error al calcular el promedio de edad');
        }
        res.status(200).json(results[0]);
    });
});

// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
